#include <stdio.h>
#include <stdlib.h>
#include <time.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
   int i, n, num;
   time_t t;
   
   n = 5;
   
   /* Inicializar la semilla para el generador de numeros aleatorios */
   srand(time(0)); 

   printf("\n\nGenerar numeros del 0 al 49\n");
   for( i = 0 ; i < n ; i++ ) {
      printf("%d\n", rand() % 50);
   }
   
   printf("\n\nGenerar numeros del 15 al 30\n");
   for( i = 0 ; i < n ; i++ ) {
      num=rand() % 16; //genera del 0 al 15 
      num= num+15; // le sumamos al numero generado 15 para llevarlo al rango del 15 al 30
      printf("I%d\n", num);
   }
   return(0);
}

