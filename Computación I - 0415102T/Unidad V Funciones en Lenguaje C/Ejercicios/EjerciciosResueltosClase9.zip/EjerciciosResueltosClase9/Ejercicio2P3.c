#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

int maximo (int x, int y);

int main(int argc, char *argv[]) {
    int num3, aux, res;
    
    int num1=10,num2=15;
    
    /*
	printf("\nIngrese tres numeros enteros: ");
    scanf("%d %d %d", &num1,&num2,&num3);
	*/
    
    aux = maximo(num1,num2);
    
    printf("\n num1 %d", num1);
    printf("\n num2 %d", num2);
	printf("\n aux %d", aux);
    
    //printf("\nEl maximo es %d", maximo(aux,num3) );
    
    
    /*Multiplicar por 5 el maximo y restarle 3*/
    //res = maximo(aux,num3) * 5 - 3;
    
    
    //printf("\nEl calculo es %d",res );
    getch();
	return 0;
}

int maximo (int num1, int num2) {
      num1++;
      num2++;
	  if ( num1 > num2 ) 
        return num1;
      else return num2;    
}




