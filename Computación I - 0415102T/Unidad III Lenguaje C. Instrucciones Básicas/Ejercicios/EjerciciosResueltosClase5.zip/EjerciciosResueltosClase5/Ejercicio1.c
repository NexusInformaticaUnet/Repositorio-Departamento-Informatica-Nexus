#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    char nombre[20];
		
	printf("Ingrese su nombre: ");
	scanf("%s",nombre);
	
	printf("Bienvenid@ %s",nombre);

	return 0;
}
