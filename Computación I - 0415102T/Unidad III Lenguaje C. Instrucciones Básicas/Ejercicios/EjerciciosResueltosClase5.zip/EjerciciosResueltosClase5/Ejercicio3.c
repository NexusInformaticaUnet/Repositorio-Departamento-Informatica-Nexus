#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
	char cliente[30], clienteMayor[30];
	int km_pre, km_post, recorrido, pago, acumPagos, contTarifBas, mayor=0;
	int contG, contPagoRango;
	char resp;
	float porc;
	
	acumPagos=0;
	contTarifBas=0;
	contG=0;
	contPagoRango=0;
	do{
	    printf("\nNombre del cliente: ");
		gets(cliente);	
		printf("\nCantidad de Km cuando recibio el auto: ");
		scanf("%d",&km_pre);
		printf("\nCantidad de Km cuando entrego el auto: ");
		scanf("%d",&km_post);
		contG = contG + 1;
		
		recorrido = km_post-km_pre;
		
		if (recorrido < 560)
		{   pago = 6500;
		    contTarifBas = contTarifBas + 1;
	    }
		else if (recorrido <= 720) 
		         pago = 6500 + (2000 * (recorrido-560)); 
		     else
			     pago = 6500 + 2000 * (720-560) + 1200 * (recorrido - 720);		    
		
		printf("\n%s su recorrido fue %d y su pago es: %d",cliente,recorrido,pago);
		
		acumPagos = acumPagos + pago;    //es igual a   acumPagos += pago; 
		
		if (pago > mayor)
		{   mayor = pago;
	        strcpy(clienteMayor,cliente); //String copy strcpy	    
		}
		
		if (pago>=10350 && pago<=18450)
		    contPagoRango = contPagoRango + 1; 
		
		printf("\nDesea continuar s/n: ");
		resp=getche();
		fflush(stdin);
		
	}while (resp=='S' || resp=='s');
	
	printf("\nEl total recaudado es Bs.: %d",acumPagos);
	printf("\nNumero de clientes que pagaron la tarifa minima: %d", contTarifBas);
	printf("\nEl cliente que pago la mayor factura es: %s", clienteMayor);
	
	porc = contPagoRango * 100 / contG;
	printf("\nEl porcentaje de clientes que pagaron entre 10350 y 18450 fue %f%",porc);
	
	return 0;
}


//    Nclientes                  --- 100%
//    Nclientes [10350,18450]    ---   ?


