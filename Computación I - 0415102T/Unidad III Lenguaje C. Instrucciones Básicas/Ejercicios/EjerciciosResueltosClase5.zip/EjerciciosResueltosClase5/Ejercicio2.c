#include <stdio.h>
#include <stdlib.h>


int main(int argc, char *argv[]) {
    char nombre[20];
    int edad;
		
	printf("Ingrese su nombre: ");
	gets(nombre);
	printf("Ingrese su edad: ");
	scanf("%d",&edad);
	
	if (edad>=18)
	    printf("Bienvenid@ %s eres mayor de edad",nombre);
	else
	    printf("Bienvenid@ %s No eres mayor de edad",nombre);    
	
	return 0;
}
