#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 1

int main(int argc, char *argv[]) {
	int i;
	char identif[10], tipo[10];
	float peso, diametro;
	
	for (i=0; i<MAX; i++){
		fflush(stdin);
	    printf("\n\nIngrese la identificacion: ");
	    gets(identif);
	    printf("\nPeso: ");
	    scanf("%f",&peso);
	    printf("\nDiametro: ");
	    scanf("%f",&diametro);
		
		//tipo="rechazada";	 No funciona asi en Lenguaje C
		strcpy(tipo,"Rechazada");  //string copy
		
		if (peso < 300){
		    if (diametro>=7 && diametro<=9)
			    strcpy(tipo,"Natural");
	    }else if (peso <=450){
		         if (diametro>=8 && diametro<=11)
			         strcpy(tipo,"Extra");
			 }else //Es > 450
			     if (diametro>=9 && diametro<=12)
			         strcpy(tipo,"Premium");  					
		
		printf("\nLa naranja %s es de tipo %s",identif,tipo);		
	}
		
	return 0;
}
