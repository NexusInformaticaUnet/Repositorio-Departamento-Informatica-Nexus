#include <stdio.h>
#include <stdlib.h>


int main(int argc, char *argv[]) {
	 char resp;
	 int lectura1, lectura2;
	 float presionProm;
	
	
     printf("\nEl dia de hoy funciono la caldera S/N: ");	
     resp=getche();
     
     while (resp=='S' || resp=='s'){
          printf("\n\nIngrese la lectura 1: ");
          scanf("%d",&lectura1);
          printf("\nIngrese la lectura 2: ");
     	  scanf("%d",&lectura2);
          
          presionProm = (lectura1 + lectura2) / 2;
          
          if (presionProm < 180)
             printf("\nLa situacion es BAJA");
          else if (presionProm < 350)    
	              printf("\nLa situacion es MODERADA");
	           else if (presionProm < 590)  
			           printf("\nLa situacion es ACEPTABLE");   
					else if (presionProm < 750) 
					        printf("\nLa situacion es de RIESGO");  
					     else
						    printf("\nLa presion promedio supera el rango maximo");
		  
		  printf("\n\nDesea continuar procesando lecturas S/N: ");
		  resp=getche();					  		    
	 }
	 	
	return 0;
}
