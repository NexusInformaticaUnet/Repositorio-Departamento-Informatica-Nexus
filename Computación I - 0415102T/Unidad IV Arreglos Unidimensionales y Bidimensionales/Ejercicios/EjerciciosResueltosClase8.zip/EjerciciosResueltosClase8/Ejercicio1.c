#include <stdio.h>
#include <stdlib.h>

#define TAM 10

int main(int argc, char *argv[]) {
	char nombre[40]; //Guarda un solo nombre
	
	char vTrabajador[TAM][40]; //Guarda 10 nombres
	int vTipo1[TAM];
	int vTipo2[TAM];
	int N,i,mayorTipo2, posMayorTipo2, alambreTipo1, alambreTipo2, acumAlambre;
	int acumResortesTipo1, acumResortesTipo2;
	float mtAlambreUtilizado;
	char resp;
	
	N=0;
	do{ 
	    fflush(stdin);
		printf("\nIngrese el nombre del trabajador: ");
		gets(vTrabajador[N]);
		printf("\nResortes elaborados del tipo 1: ");
		scanf("%d",&vTipo1[N]);
		printf("\nResortes elaborados del tipo 2: ");
		scanf("%d",&vTipo2[N]);
		N++;
		printf("\nDesea continuar s/n: ");
		resp=getche();
		
	}while ((resp=='s' || resp=='S') && N<TAM);
	
	//a.	Cual fue el trabajador que produjo m�s resortes del tipo 2.	
	mayorTipo2 = vTipo2[0];
	for(i=1; i<N; i++){
		if (vTipo2[i]>mayorTipo2){
			mayorTipo2=vTipo2[i];
			posMayorTipo2=i;
		}		   
	}
	printf("\n\nEl trabajador que produjo mas resortes del tipo 2 (%d) fue %s",mayorTipo2,vTrabajador[posMayorTipo2]);
	
	//b.	Si para producir un resorte del tipo 1 se requiere 25 cm. de alambre y 
	//      para producir un resorte del tipo 2 se requiere 30 cm. de alambre, calcular 
	//      la cantidad de metros de alambre utilizados en la producci�n de la semana.
	acumAlambre=0;
	for(i=0; i<N; i++){
		alambreTipo1 = vTipo1[i]*25;
		alambreTipo2 = vTipo2[i]*30;
		acumAlambre = acumAlambre + (alambreTipo1 + alambreTipo2);
	}
	
	//  100 cm         ---  1 metro
	//  acumAlambre cm ---    ? 
	mtAlambreUtilizado = acumAlambre/100;      
	printf("\n\nLa cantidad de alambre necesaria para la produccion de todos los resortes es: %.2f metros",mtAlambreUtilizado);
	
	//c.	Asumiendo que al inicio de la semana la f�brica no dispone de resortes para 
	//      la venta y se recibe un pedido de 3500 resortes del tipo 1 y 4200 del tipo 2, 
	//      para ser entregado al finalizar la semana, indique si la fabrica cumple o no 
	//      con el pedido solicitado.
	acumResortesTipo1=0;
	acumResortesTipo2=0;
    for(i=0; i<N; i++){
		acumResortesTipo1 = vTipo1[i];
		acumResortesTipo2 = vTipo2[i];	
	}
	printf("\n\n----------------------");
	printf("\nProduccion de Resortes");
	printf("\n  Tipo 1      Tipo 2");
	printf("\n   %d \t\t %d",acumResortesTipo1,acumResortesTipo1);
	if (acumResortesTipo1>=3500 && acumResortesTipo2>=4200)
	    printf("\nLa fabrica cumple con el pedido solicitado");
    else
	    printf("\nLamentablemente, la fabrica no cumple con el pedido solicitado");
	
	
	return 0;
}
