#include <stdio.h>
#include <stdlib.h>

#define MaxFilas 35
#define Ncol 16

int main(int argc, char *argv[]) {
	char vDirecciones[16][4]={"N","NNE","NE","ENE","E","ESE","SE","SSE","S","SSW","SW","WSW","W","WNW","NW","NNW"};
	char vMunicipio[MaxFilas][40];
	float mVelocidad[MaxFilas][Ncol];
	float vPromDir[Ncol];
	int Nfil,j,i,cont,encontreMun,encontreDir,iBuscar,jBuscar;
	char resp;
	char munBuscar[40],dirBuscar[4];
	float vMayorVelMun[MaxFilas],mayorVelPorMun,mayor;
	
	//a.	Cargar en arreglos la informaci�n conocida: Velocidad del viento en las 
	//      16 direcciones en c/u de los municipios del estado, los municipios, 
	//      considerando como m�ximo 35 y las diferentes direcciones.
	Nfil=0;
	do{ 
	    fflush(stdin);
		printf("\n\nIngrese el nombre del municipio: ");
		gets(vMunicipio[Nfil]);
		for(j=0; j<Ncol; j++){
			printf("\nIngrese la velocidad del viento en la direccion %s: ",vDirecciones[j]);
			scanf("%f",&mVelocidad[Nfil][j]);
		}
		Nfil++;
		printf("\nDesea continuar con otro municipio S/N: ");
		resp=getche();
		
	}while ((resp=='s'||resp=='S') && Nfil<MaxFilas);
	
	//b.	Calcular la velocidad promedio por cada direcci�n en un arreglo unidimensional 
	//      exceptuando aquellos municipios en donde el viento no super� 5 km/h. Mostrar 
	//      dichos promedios con su respectiva direcci�n.
	printf("\n\nDirecciones    Promedio");  
	for(j=0; j<Ncol; j++){ //ciclo de las columnas
		vPromDir[j] = 0.0;
		cont = 0;
		for(i=0; i<Nfil; i++){ //ciclo de las filas
		    if (mVelocidad[i][j] > 5){
			    vPromDir[j] = vPromDir[j] + mVelocidad[i][j];
			    cont++;
		    }
	    }
	    if (cont > 0) 
		    vPromDir[j] = (float) vPromDir[j] / cont;
		    
		printf("\n   %s \t\t %.2f",vDirecciones[j],vPromDir[j]);    
    }
    
    //c.	Encuentre e imprima la velocidad alcanzada en un municipio en particular 
	//      ingresado por el usuario en una direcci�n particular tambi�n ingresada por el usuario.
	fflush(stdin);
	printf("\n\nBuscador...");
	printf("\nIngrese el municipio: ");
	gets(munBuscar);
	iBuscar = 0;
	encontreMun = 0;
	while (iBuscar < Nfil && encontreMun == 0){
		if(strcmpi(vMunicipio[iBuscar],munBuscar)==0)
		   encontreMun = 1;	
	    else iBuscar++;	
		
    }
    printf("\nIngrese la direccion del viento: ");
	gets(dirBuscar);
	jBuscar=0;
	encontreDir=0;
	while (jBuscar < Ncol && encontreDir == 0){
		if(strcmpi(vDirecciones[jBuscar],dirBuscar)==0)
		   encontreDir = 1;	
		else jBuscar++;
    }
	if(encontreMun==1 && encontreDir==1)  
	   printf("\nVelocidad alcanzada: %.2f",mVelocidad[iBuscar][jBuscar]);  
	else 
	   printf("\nDatos no validos");
	
	//d.	Con el fin de identificar los municipios en estado de alerta por la alta velocidad 
	//      del viento guarde en un arreglo unidimensional la mayor de las velocidades 
	//      registradas por cada municipio, asumiendo de que existe una �nica velocidad mayor. 
	//      Luego, emita un listado del o los municipios que se encuentran en estado de alerta 
	//      por precipitaciones al registrar la mayor velocidad del viento.       
	for(i=0; i<Nfil; i++){ //ciclo de las filas
	    mayorVelPorMun= mVelocidad[i][0]; //Inicializo mayor en la primera velocidad registrada del municipio
		for(j=1; j<Ncol; j++) //ciclo de las columnas
		    if (mVelocidad[i][j] > mayorVelPorMun)
			    mayorVelPorMun = mVelocidad[i][j];	
		vMayorVelMun[i] = mayorVelPorMun;	    	    
    }
	//Busco entre las mayores tenperaturas de cada municipio, cual es la temperatura mayor
	mayor= vMayorVelMun[i];
	for(i=0; i<Nfil; i++){ //ciclo de las filas
	    if (vMayorVelMun[i] > mayor)
			    mayor = vMayorVelMun[i];	    	    
    }
    //Imprimo los municipios que tengan esa temperatura mayor
    printf("\n\nMunicipios que tienen la mayor velocidad = %.2f y estan en estado de alerta",mayor);
    for(i=0; i<Nfil; i++){ //ciclo de las filas
	    if (vMayorVelMun[i] == mayor)
			printf("\n\t\t\t  %s",vMunicipio[i]);    	    	    
    }
	
	printf("\n\n");    	    	    
	
	
	return 0;
}
