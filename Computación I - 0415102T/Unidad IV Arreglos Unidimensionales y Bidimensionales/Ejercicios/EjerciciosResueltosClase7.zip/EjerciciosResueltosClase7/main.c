#include <stdio.h>
#include <stdlib.h>

#define tam 20
#define TRUE 1
#define FALSE 0

int main(int argc, char *argv[]) {
	float vTempPorDia[tam], acum, prom, menor, mayor, elementoBuscar;
	int N, i, cont, posMayor, posMenor;
	char pais[30], resp;
	int encontre;
	
	printf("\nPais: ");
	gets(pais);
	//Carga de las temperaturas en el arreglo
	N=0;
	do{
		printf("\nIngrese la temp (grados F) del dia %d: ",(N+1));
		scanf("%f",&vTempPorDia[N]);
		N++;
		printf("\nDesea continuar s/n: ");
		resp=getche();
	}while((resp=='S'||resp=='s') && N<tam);
	
	//Mostramos las temperaturas almacenadas
	printf("\n\nListado de temperaturas por dia");
	printf("\n-------------------------------");	
	for(i=0; i<N; i++){
	    printf("\nDia %d: %f",(i+1),vTempPorDia[i]);	
	}
	
	//Resp Temperatura promedio
	acum=0.0;
	for(i=0; i<N; i++){
		acum = acum + vTempPorDia[i];	   	
	}	
	prom = (float) acum / N;
	printf("\nLa temperatura promedio de %s fue %f",pais,prom);
	
	//Cantidad de dias en que la temp rebas� 105 F pero no tome en cuenta el primer y �ltimo registro
	cont=0;
	for(i=1; i<(N-1); i++){ //asi chequeo que el primer y �ltimo registro no se tomen en cuenta
		if (vTempPorDia[i]>105)
		    cont++;	   	
	}
	printf("\n\nEn %d dias la temperatura rebaso los 105 F",cont);	
	
	//B�squeda de la mayor y menor temperatura 
	mayor = vTempPorDia[0];
	menor = vTempPorDia[0];
	for(i=1; i<N; i++){
		if (vTempPorDia[i]>mayor){
			mayor=vTempPorDia[i];
			posMayor = i;
		}
		if (vTempPorDia[i]<menor){
			menor=vTempPorDia[i];
			posMenor = i;
		}		
	}
	printf("\nLa mayor temperatura fue : %f y fue el dia %d ", mayor, posMayor+1);
	printf("\n\nLa menor temperatura fue : %f y fue el dia %d ", menor, posMenor+1);
	
	//Indicar si hubo un dia con temperatura de 99 F
	elementoBuscar=99;
	encontre=FALSE;
	i=0;
	while (i<N && encontre==FALSE){   //while (i<N && !encontre)
        if (vTempPorDia[i]==elementoBuscar)
           encontre=TRUE;
        
		i++;   
	}
	
	if (encontre==TRUE)   //if (encontre)
	    printf ("\nSI hubo por lo menos un dia con temperatura %f F",elementoBuscar);
	else 
	    printf ("\nNO hubo un dia con temperatura %f F",elementoBuscar);    
	return 0;
}
