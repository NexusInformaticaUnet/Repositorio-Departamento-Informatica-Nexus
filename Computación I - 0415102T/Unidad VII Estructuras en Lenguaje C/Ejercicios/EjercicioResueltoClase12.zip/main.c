#include <stdio.h>
#include <stdlib.h>

#define MAX 10

typedef struct {
	int piso;
	char habitacion[5];
}tipo_ubicacion;

typedef struct{
	char nombre[30];
	char sexo;
	float deposito;
	tipo_ubicacion ubicacion;
}tipo_paciente;

tipo_paciente vector [MAX];


// Prototipos de funciones
int cargar_datos(tipo_paciente vector[]);
float calcular_1(tipo_paciente vec[], int N, int *cantM);
void paciente_con_mayor_deposito(tipo_paciente vec[], int N);


// Funcion principal
int main(int argc, char *argv[]) {
	int N;
	int cantMasculino=0;
	
	N = cargar_datos(vector);
	printf ("\n N = %d ",N);
	
	printf("\nEl total depositado por los pacientes femeninos del piso 2 es Bs. %.2f", calcular_1(vector, N, &cantMasculino) );
	printf("\nLa cantidad de pacientes de sexo masculino del piso 2 es %d",cantMasculino);
	
	paciente_con_mayor_deposito(vector, N);
	
	return 0;
}

//Definicion de funciones
int cargar_datos(tipo_paciente vec[]){
	int pos; 
	char resp;
	
	pos=0;
	printf("\nIngrese los siguientes datos de cada paciente");
	printf("\n---------------------------------------------\n");
	do{
		fflush(stdin);
		printf("\nNombre: ");
		gets(vec[pos].nombre);
		printf("\nSexo: ");
		vec[pos].sexo = toupper(getche());
		printf("\nMonto del deposito: ");
		scanf("%f",&vec[pos].deposito);	
		printf("\nUbicacion   Piso: ");
		scanf("%d",&vec[pos].ubicacion.piso);			
		printf("\n            Habitacion: ");
		scanf("%s",&vec[pos].ubicacion.habitacion);
		pos++;
		printf("\n\nHay mas pacientes por cargar s/n: ");
		resp = toupper(getche());
	}while (pos<MAX && resp=='S');
	return pos;
}

//Para el piso 2: Total depositado, en Bs., por los pacientes femeninos
//                Cantidad de pacientes masculinos 
float calcular_1(tipo_paciente vec[], int N, int *cantM){
     int i;
     float acum;
     int cont;
     
     acum=0; cont=0;
     for (i=0; i<N; i++){
     	if (vec[i].ubicacion.piso==2){
		
     	    switch(vec[i].sexo){
     	    case 'F': {
			             acum = acum + vec[i].deposito;
				         break;
					  }
			case 'M': {
				         cont++;
			     	     break;
			          }	
			}
		}
	 }
	 *cantM = cont;
	 return acum; 
}

//Paciente con mayor deposito
void paciente_con_mayor_deposito(tipo_paciente vec[], int N){
     int i;
     float mayor;
     int posMayor;
     
     mayor=vec[0].deposito;
     posMayor=0;
     for (i=1; i<N;i++){
     	if (vec[i].deposito>=mayor){
     		mayor=vec[i].deposito;
     		posMayor=i;		
		}
	 }	 
	 printf("\nEl paciente %s fue el que tuvo el mayor deposito %.2f y estuvo en el piso %d ", vec[posMayor].nombre, mayor, vec[posMayor].ubicacion.piso);		
}










